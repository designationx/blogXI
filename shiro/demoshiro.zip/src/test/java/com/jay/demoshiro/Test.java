package com.jay.demoshiro;

/**
 * @Author: Jay_Liu
 * @Description:
 * @Date: Created in 12:06 2018/3/27 0027
 * @Modified By:
 */
public class Test {

    public static void main(String[] args) {

    }

}
